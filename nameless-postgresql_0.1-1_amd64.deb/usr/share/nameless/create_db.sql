/********** NAMELESS - CREATE POSTGRESQL DATABASE **********
 *
 *   author = Antonio Pastor <anpastor@it.uc3m.es>
 *   license = GNU/GPLv3
 *
 ***********************************************************/

CREATE DATABASE nameless;
\connect nameless ;

CREATE SCHEMA IF NOT EXISTS lookup;
CREATE SCHEMA IF NOT EXISTS raw_log;
CREATE SCHEMA IF NOT EXISTS log;
CREATE SCHEMA IF NOT EXISTS stats;

ALTER DATABASE nameless set search_path TO public,stats,log,raw_log,lookup;

CREATE TABLE lookup.domains (
id serial,
domain text COLLATE "C",
PRIMARY KEY(id),
UNIQUE (domain) WITH (fillfactor=10)
)
WITH (fillfactor=10);
INSERT INTO lookup.domains (domain) VALUES (null);  -- null value gets id 1


-- Generic raw_log table
CREATE TABLE raw_log._log (
  tstamp timestamp without time zone DEFAULT NULL,
  ip cidr DEFAULT NULL, -- classless inter-domain routing IP type
  referrer int DEFAULT NULL,
  ssp int DEFAULT NULL
);

CREATE VIEW raw_log.log AS SELECT
  tstamp,
  ip,
  (SELECT domain FROM lookup.domains WHERE id=a.referrer) AS referrer,
  (SELECT domain FROM lookup.domains WHERE id=a.ssp) AS ssp
FROM raw_log._log a;


-- Generic log table
CREATE TABLE log._log (
  tstamp timestamp without time zone DEFAULT NULL,
  ip cidr DEFAULT NULL, -- classless inter-domain routing IP type
  referrer int DEFAULT NULL,
  agg_count int DEFAULT NULL
);

CREATE VIEW log.log AS SELECT
  tstamp,
  ip,
  (SELECT domain FROM lookup.domains WHERE id=a.referrer) AS referrer,
  agg_count
FROM log._log a;


--stats tables
CREATE TABLE stats.ip (
  ip cidr NOT NULL PRIMARY KEY
)
WITH (fillfactor=10);

CREATE TABLE stats.referrer (
  referrer int NOT NULL PRIMARY KEY
)
WITH (fillfactor=10);

